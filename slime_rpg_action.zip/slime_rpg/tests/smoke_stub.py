"""Runs main.py's game loop against a FAKE 'ursina' module, to catch Python-level mistakes in the glue code
(typos, wrong attribute use, logic errors). It cannot check the real Ursina API: that needs a real run.
Usage (project root):  python tests/smoke_stub.py"""
import collections
import math
import importlib
import os
import sys
import tempfile
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import config as _C                                            # noqa: E402

_tmp = tempfile.mkdtemp(prefix="slime_smoke_")
os.environ["SLIME_SEED"] = str(_C.SEED)                        # a fixed map for this script (new games are random otherwise)
os.environ["SLIME_SAVE_DIR"] = os.path.join(_tmp, "save")      # never touch a real save

# a MODs folder with one good MOD (with a misspelt key = a warning) and one broken MOD
import json as _json                                           # noqa: E402
_mods = os.path.join(_tmp, "mods")
os.environ["SLIME_MODS_DIR"] = _mods
for _folder, _meta, _slimes in (
        ("smoke_ok", {"id": "smoke_ok", "name": "Smoke Mod", "api_version": 1},
         [{"id": "smoke_slime", "name": "Smoke Slime", "weight": 1, "colour": [1, 2, 3]}]),
        ("smoke_bad", {"id": "smoke_bad", "name": "Bad Mod", "api_version": 1, "enabled": "yes"}, [])):
    os.makedirs(os.path.join(_mods, _folder))
    _json.dump(_meta, open(os.path.join(_mods, _folder, "mod.json"), "w"))
    _json.dump(_slimes, open(os.path.join(_mods, _folder, "slimes.json"), "w"))


class Fake:
    def __init__(self, *a, **k):
        self.__dict__.update(k)
        self.args = a

    def __getattr__(self, name):      # unknown attributes read as harmless fakes
        if name.startswith("__"):
            raise AttributeError(name)
        return Fake()


played = []
destroyed = []
fake = types.ModuleType("ursina")
for n in ("Ursina", "Entity", "Text", "Mesh", "Color", "Texture", "Button"):
    setattr(fake, n, type(n, (Fake,), {}))


music_log = []


class FakeClip:
    """Stands in for Panda3D's AudioSound: remembers whether it is playing."""

    def __init__(self, name):
        self.name, self.playing = name, False

    def setLoop(self, *a): pass
    def setVolume(self, *a): pass
    def setTime(self, *a): pass

    def play(self):
        self.playing = True
        music_log.append(("start", self.name))

    def stop(self):
        self.playing = False
        music_log.append(("stop", self.name))

    def status(self):
        return 2 if self.playing else 1


class Audio(Fake):
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.clip = FakeClip(str(a[0]))

    def play(self, *a):
        if str(self.args[0]).startswith("bgm_"):
            self.clip.play()
        else:
            played.append(self.args[0])


fake.Audio = Audio
fake.camera = Fake(forward=Fake(x=0.0, y=-1.0, z=0.0), ui=Fake())
fake.window = Fake(exit_button=Fake(), color=None)
fake.mouse = Fake(velocity=(0.0, 0.0, 0.0), locked=False)
tints = []
fake.scene = Fake(setColorScale=lambda *a: tints.append(a))
fake.held_keys = collections.defaultdict(float)
quit_calls = []
fake.application = Fake(quit=lambda: quit_calls.append(1))
fake.destroy = lambda e: destroyed.append(e)
fake.time = Fake(dt=1 / 60)
sys.modules["ursina"] = fake

import random                    # noqa: E402
import main                      # noqa: E402  (builds the world, prefetches chunks, loads sounds)
import config as C               # noqa: E402
from blocks import BLOCKS        # noqa: E402

main.rng = random.Random(1)      # deterministic: no surprise fights while this script walks around
from game.enemies import EnemyManager, ActionEnemy      # noqa: E402
EnemyManager.spawning = False                            # no ordinary slimes until the combat section switches them on
# MODs: the good one loaded, the broken one was skipped, the typo was reported, and the player is told in the game
assert [m["id"] for m in main.MODS.loaded] == ["smoke_ok"], main.MODS.loaded
assert len(main.MODS.errors) == 1 and "enabled" in main.MODS.errors[0], main.MODS.errors
assert len(main.MODS.warnings) == 1 and "colour" in main.MODS.warnings[0], main.MODS.warnings
assert "skipped" in main.message.text and "warning" in main.message.text, main.message.text
main.message.enabled = False                               # (the notice has been read; later checks look at fresh messages)
assert main.mod_summary() == "MODs: Smoke Mod (S:1 B:0)   (2 problem(s): see the terminal)", main.mod_summary()
assert music_log[0][0] == "start" and music_log[0][1].startswith("bgm_field_v1_"), music_log[:2]
assert not any("bgm_battle" in n and e == "start" for e, n in music_log), "only the field tune plays at the start"

print("spawn:", tuple(round(v, 2) for v in main.SPAWN), "| entities after prefill:", len(main.chunk_entities))
assert main.chunk_entities, "no chunk meshes were built"

for _ in range(120):             # settle onto the ground
    main.update()
print("on ground:", main.body.on_ground, "y=%.2f" % main.body.y)
assert main.body.on_ground

# Shrink the inventory to 1 slot so "full" is reachable (with 4 block types and stacks of 64 a real
# 20-slot inventory takes ~1000 blocks to fill; minerals in stage 3 will make it fill much faster).
main.inventory.slots = [None] * 1

# Dig straight down with the button held, as a player would.
fake.held_keys["left mouse"] = 1.0
broke_at = []
for frame in range(60 * 120):
    main.update()
    if main.inventory.used_slots() and not broke_at:
        broke_at.append(frame)
    if main.message.enabled:
        break
print("first block after %.2fs; sounds so far: %s" % (broke_at[0] / 60 if broke_at else -1, sorted(set(played))))
assert broke_at and any(s.startswith("hit_") for s in played) and any(s.startswith("break_") for s in played)

print("inventory:", main.inventory.slots[:4], "| used", main.inventory.used_slots())
print("message shown:", main.message.enabled, repr(main.message.text))
assert main.inventory.is_full(), "digging should eventually fill the inventory"
assert "Inventory full" in main.message.text and "full" in played

print("depth/fog after digging a shaft:", main.st.fog_depth)
assert main.st.fog_depth >= 2, "a dug shaft must still count as deep"

# Back on the surface: place with right-click while aiming at the ground ahead.
from blocks import ROCK          # noqa: E402
sx, sy, sz = main.SPAWN
main.body.x, main.body.z = sx + 3, sz            # away from the shaft we just dug
main.body.y = main.world.surface_y(int(sx + 3), int(sz)) + 1.01
main.body.vy = 0.0
main.inventory.slots = [None] * C.INVENTORY_SLOTS
main.inventory.add(ROCK, 5)
main.input("1")
fake.camera.forward = Fake(x=0.0, y=-0.6, z=0.8)
for _ in range(30):
    main.update()
before = main.inventory.count(ROCK)
main.input("right mouse down")
after = main.inventory.count(ROCK)
print("place: rock %d -> %d | 'place' sound played: %s" % (before, after, "place" in played))
assert after == before - 1 and "place" in played
main.input("q")
assert main.inventory.count(ROCK) == after - 1

# Walk around to exercise streaming / unloading.
fake.held_keys["w"] = 1.0
fake.mouse.velocity = (0.0, 0.0, 0.0)
fake.camera.forward = Fake(x=0.0, y=0.0, z=1.0)
fake.held_keys["space"] = 1.0
for _ in range(60 * 12):
    main.update()
print("walked to z=%.1f | meshed chunks: %d | entities: %d | destroyed: %d"
      % (main.body.z, len(main.manager.meshed), len(main.chunk_entities), len(destroyed)))
print("fog depth state:", main.st.fog_depth)
fake.held_keys["w"] = 0.0
fake.held_keys["space"] = 0.0

# ---- eating a mineral with E (stage 3)
import items                    # noqa: E402
main.inventory.slots = [None] * C.INVENTORY_SLOTS
rare = items.item_of(items.code_from_rgb((200, 60, 60)))           # vivid red
main.inventory.add(rare, 2)
main.inventory.add(ROCK, 1)
main.input("1")
c0, hp0 = main.stats.color, main.stats.hp
main.input("e")
assert main.inventory.count(rare) == 1, "eating should consume one mineral"
assert main.stats.color[0] > c0[0] and main.stats.color[1] < c0[1], "colour should move toward the mineral"
assert main.stats.hp < hp0, "a distant colour should hurt"
assert main.message.text.startswith("Ate mineral: HP -"), main.message.text
assert "eat" in played
main.input("2")
main.input("e")
assert main.message.text == "Select a mineral to eat (E)" and main.inventory.count(ROCK) == 1
main.update()
assert "HP" in main.hud_status.text and "Hue" in main.hud_status.text, main.hud_status.text
print("eat: hp %d -> %d, colour %s -> %s" % (hp0, main.stats.hp, tuple(round(v) for v in c0),
                                             tuple(round(v) for v in main.stats.color)))


# ---- action combat (stage 9): slimes stand in the world, wake up within 4 blocks, bite, get hit, die
import json                      # noqa: E402
from blocks import WOOD, AIR     # noqa: E402
from game.battle import make_enemy   # noqa: E402

HUD = ("hud_inventory", "hud_status", "hud_info", "hud_help", "swatch_you", "swatch_held", "crosshair", "label_you", "label_held")


def last_idx(kind, prefix):
    return max(i for i, (e, n) in enumerate(music_log) if e == kind and n.startswith(prefix))


def aim_at(e):
    """Point the (fake) camera at the middle of a slime, the way a player looks at it."""
    eye = (main.body.x, main.body.y + C.EYE_HEIGHT, main.body.z)
    c = e.center()
    fake.camera.forward = Fake(x=c[0] - eye[0], y=c[1] - eye[1], z=c[2] - eye[2])


def run(frames, until=None):
    for i in range(frames):
        main.update()
        if until is not None and until():
            return i
    return frames


def platform(X, Z, w=14, d=14, block=ROCK):
    """A slab of `block` with free air above it, high above the ground; returns the Y of its top face (standing level)."""
    P = main.world.surface_y(X, Z) + 8
    for dx in range(w):
        for dz in range(d):
            main.world.set_block(X + dx, P, Z + dz, block)
            for dy in range(1, 8):
                main.world.set_block(X + dx, P + dy, Z + dz, AIR)
    return P + 1


def put_player(x, y, z):
    main.body.x, main.body.y, main.body.z = x, y, z
    main.body.vy = 0.0
    main.st.yaw = 0.0


main.rng = random.Random(5)
main.stats.base = {"hp": 400, "atk": 60, "def": 30, "spd": 30}
main.stats.restore_full()
fake.held_keys["w"] = 0.0
fake.held_keys["left mouse"] = 0.0
fake.held_keys["right mouse"] = 0.0
Y0 = platform(40, 40)
put_player(47.5, Y0 + 0.01, 43.5)
run(10)
e = main.enemies.add(ActionEnemy(main.world, make_enemy(3, main.rng), 47.5, Y0 + 0.001, 50.5))     # 7 blocks away
run(60)
assert e.entity is not None and abs(e.z - 50.5) < 1e-6 and not e.chasing, "a slime farther than 4 blocks stands still"
assert main.st.music == "field"
put_player(47.5, Y0 + 0.01, 47.0)                                       # 3.5 blocks away: it wakes up
z0 = e.z
run(25)
assert e.chasing and e.z < z0 - 0.3, "within 4 blocks it chases"
assert main.st.music == "battle" and last_idx("start", "bgm_battle") == len(music_log) - 1, music_log[-3:]
print("slime: still at 7 blocks, chases at 3.5, battle music on")

hp0 = main.stats.hp
run(200, until=lambda: main.stats.hp < hp0)
assert main.stats.hp < hp0, "a slime that reaches you bites"
assert main.st.screen_flash > 0 and main.flash_ui.enabled, "the screen flashes red when you are hit"
assert "impact" in played
print("bite: hp %d -> %d, red flash on" % (hp0, main.stats.hp))

# hitting it: white flash and a little push back, no digging, experience on the kill
e.stats.max_hp = e.stats.hp = 5000
aim_at(e)
inv_before = [list(x) if x else None for x in main.inventory.slots]
fake.held_keys["left mouse"] = 1.0
d0 = ((e.x - main.body.x) ** 2 + (e.z - main.body.z) ** 2) ** 0.5
hp_e = e.stats.hp
run(8)
assert e.stats.hp < hp_e, "a left click on a slime hurts it"
assert e.entity.color.args[:3] == (1, 1, 1) or e.flash > 0 or e.knock_t > 0, "white flash on a hit"
assert main.miner.progress == 0.0 and [list(x) if x else None for x in main.inventory.slots] == inv_before, "attacking must not dig"
fake.held_keys["left mouse"] = 0.0
e.stats.hp = 1
lv0, xp0 = main.stats.level, main.stats.xp
aim_at(e)
fake.held_keys["left mouse"] = 1.0
run(120, until=lambda: not e.alive)
fake.held_keys["left mouse"] = 0.0
assert not e.alive and e not in main.enemies.enemies and e.entity is None, "a beaten slime is gone"
assert (main.stats.level, main.stats.xp) != (lv0, xp0) and "win" in played, "a kill gives experience"
assert "beaten" in main.message.text, main.message.text
run(150)
assert main.st.music == "field", "the calm music returns when nothing chases you"
print("hit: damage, white flash, knock-back, no digging; kill gives xp (Lv %d, %d xp)" % (main.stats.level, main.stats.xp))

# a mineral is used up only when it connects; a miss costs nothing
main.stats.base = {"hp": 400, "atk": 60, "def": 30, "spd": 30}
main.stats.restore_full()
mineral = items.item_of(items.code_from_rgb((200, 60, 60)))
main.inventory.slots = [None] * C.INVENTORY_SLOTS
main.inventory.add(mineral, 5)
main.input("1")
put_player(47.5, Y0 + 0.01, 43.5)
e = main.enemies.add(ActionEnemy(main.world, make_enemy(3, main.rng), 47.5, Y0 + 0.001, 50.5))
e.stats.max_hp = e.stats.hp = 5000
fake.camera.forward = Fake(x=0.0, y=0.0, z=-1.0)                         # looking away from it
fake.held_keys["right mouse"] = 1.0
run(60)
assert main.inventory.count(mineral) == 5, "a swing that hits nothing keeps the mineral"
put_player(47.5, Y0 + 0.01, 48.8)                                         # in reach
for _ in range(120):
    aim_at(e)
    main.update()
    if main.inventory.count(mineral) < 5:
        break
fake.held_keys["right mouse"] = 0.0
assert main.inventory.count(mineral) == 4, "a mineral that connects is used up"
print("mineral: miss keeps it, hit uses one")
main.enemies.kill(e)

# a slime does not bite you on Wood
main.stats.restore_full()
Y1 = platform(70, 40, block=WOOD)
put_player(77.5, Y1 + 0.01, 43.5)
w = main.enemies.add(ActionEnemy(main.world, make_enemy(30, main.rng), 77.5, Y1 + 0.001, 47.0))
hp_safe = main.stats.hp
run(240)
assert w.chasing and main.stats.hp == hp_safe, "slimes do not bite you while you stand on Wood"
main.enemies.kill(w)
print("wood: a chasing slime never bit")

# steps: one block up is fine, two blocks stops it
Y2 = platform(100, 40)
for dz in range(14):
    for dx in range(4, 14):
        main.world.set_block(100 + dx, Y2, 40 + dz, ROCK)                 # ledge, one block high (top at Y2 + 1)
put_player(105.5, Y2 + 1.01, 46.5)
one = main.enemies.add(ActionEnemy(main.world, make_enemy(3, main.rng), 102.5, Y2 + 0.001, 46.5))
run(240)
assert one.y > Y2 + 0.9, "a slime climbs one block"
main.enemies.kill(one)
for dz in range(14):
    for dx in range(4, 14):
        main.world.set_block(100 + dx, Y2 + 1, 40 + dz, ROCK)             # now two blocks high
put_player(105.5, Y2 + 2.01, 46.5)
two = main.enemies.add(ActionEnemy(main.world, make_enemy(3, main.rng), 102.5, Y2 + 0.001, 46.5))
run(240)
assert two.y < Y2 + 0.5 and two.x < 104.0, "two blocks is too much: it stops at the foot of the ledge"
main.enemies.kill(two)
print("steps: climbs one block, stops at two")

# night extras and ordinary spawning (switch the spawner on for a moment)
EnemyManager.spawning = True
main.enemies.sync(main.manager.meshed, main.st.world_time, (main.body.x, main.body.z), budget=40)
day_count = len(main.enemies.enemies)
night_t = 0.0
main.enemies.sync(main.manager.meshed, night_t, (main.body.x, main.body.z), budget=40)
assert len(main.enemies.enemies) > day_count >= 0, (day_count, len(main.enemies.enemies))
assert any(x.night_only for x in main.enemies.enemies), "night brings extra slimes"
from world import enemy_spawn   # noqa: E402
for x in main.enemies.enemies:
    if not x.boss and x.chunk is not None:
        assert enemy_spawn.valid_spot(main.world, math.floor(x.x), math.floor(x.y), math.floor(x.z)), "no slime buried in ground or wall: %s" % ((x.x, x.y, x.z),)
print("spawn: %d slimes by day, %d at night, all standing on solid ground in free air" % (day_count, len(main.enemies.enemies)))
EnemyManager.spawning = False
for x in list(main.enemies.enemies):
    main.enemies.kill(x)

# defeat = sudden death: all items lost, back at spawn, saved immediately
main.inventory.add(ROCK, 5)
main.stats.base = {"hp": 5, "atk": 1, "def": 1, "spd": 1}
main.stats.restore_full()
put_player(47.5, Y0 + 0.01, 43.5)
killer = main.enemies.add(ActionEnemy(main.world, make_enemy(3, main.rng), 47.5, Y0 + 0.001, 45.0))
killer.stats.atk = 999
run(400, until=lambda: main.inventory.used_slots() == 0 and (round(main.body.x, 3), round(main.body.z, 3)) == (round(main.SPAWN[0], 3), round(main.SPAWN[2], 3)))
assert main.inventory.used_slots() == 0, "death must empty the inventory"
assert main.stats.hp == main.stats.max_hp
assert (round(main.body.x, 3), round(main.body.z, 3)) == (round(main.SPAWN[0], 3), round(main.SPAWN[2], 3))
assert "died" in main.message.text and "lose" in played
saved = json.load(open(os.path.join(_tmp, "save", "meta.json")))
assert all(slot is None for slot in saved["inventory"]), "death must be saved at once"
print("defeat: inventory emptied, respawned at the start point, saved")
for x in list(main.enemies.enemies):
    main.enemies.kill(x)
run(200)                                                 # the calm tune comes back once nothing chases you
main._director.wait()                                    # new tunes are being composed in the background: let them finish
# the sound system drops the music: the director notices within a couple of seconds and starts it again
field_clip = main._director.current["field"][1].audio.clip
assert field_clip.playing
field_clip.playing = False
before = main._director.restarts
run(120)
assert field_clip.playing and main._director.restarts == before + 1, "silent music must be restarted"
main.stats.base = {"hp": 50, "atk": 10, "def": 6, "spd": 8}
main.stats.restore_full()
main.body.x, main.body.y, main.body.z = main.SPAWN
main.body.vy = 0.0


# ---- day and night, villages (stage 5)
from game import daytime        # noqa: E402
from world import boss_arena, villages      # noqa: E402

noon = 0.5 * C.DAY_LENGTH
midnight = 0.0
main.st.world_time = noon
main.st.sky_key = None
main.st.fog_timer = 0.0
main.update()
sky_noon = main.window.color.args[:3]
main.st.world_time = midnight
main.st.sky_key = None
main.st.fog_timer = 0.0
main.update()
sky_night = main.window.color.args[:3]
assert sum(sky_night) < sum(sky_noon) * 0.25, (sky_noon, sky_night)
assert not tints, "by default only the sky darkens at night; the world itself is not tinted"
assert "night" in main.hud_info.text or main.st.info_timer > 0
main.st.info_timer = 0.0
main.update()
assert "Time" in main.hud_info.text and "Village" in main.hud_info.text, main.hud_info.text
t0 = main.st.world_time
for _ in range(60):
    main.update()
assert main.st.world_time > t0, "time must advance"
print("sky noon %s -> midnight %s, hud: %s" % (tuple(round(c, 2) for c in sky_noon), tuple(round(c, 2) for c in sky_night),
                                              main.hud_info.text.replace("\n", " | ")))

# ---- a village: step on the Wood tile and the commands open (no buildings)
import items                     # noqa: E402
v = villages.village_in_region(main.world.seed, 0, 0)
assert main.world.get_block(v.x, v.ground, v.z) == WOOD


def stand_on(x, y, z):
    main.body.x, main.body.y, main.body.z = x, y, z
    main.body.vy = 0.0
    main.st.last_xz = (main.body.x, main.body.z)


stand_on(v.x + 4.5, v.ground + 1.01, v.z - 4.5)
for _ in range(10):
    main.update()
assert main.st.panel is None, "the commands must not open away from the tile"
stand_on(v.x + 0.5, v.ground + 1.01, v.z + 0.5)
main.update()
assert main.st.panel is not None and main.panel_ui.enabled and not main.mouse.locked
assert main.panel_title.text == "VILLAGE " + v.id, main.panel_title.text
assert all(getattr(main, n).enabled is False for n in HUD), "the everyday text must be hidden on the village screen"
before = (main.body.x, main.body.y, main.body.z)
fake.held_keys["w"] = 1.0
for _ in range(20):
    main.update()
fake.held_keys["w"] = 0.0
assert (main.body.x, main.body.y, main.body.z) == before, "the world must stand still while the commands are open"
assert "Inn" in main.panel_buttons[0].text and "Leave" in main.panel_buttons[5].text, [b.text for b in main.panel_buttons[:7]]

# inn through the number keys: needs a common mineral, then heals and becomes the respawn point
main.stats.take_damage(15)
main.input("1")                                          # Inn
main.input("1")                                          # Stay: no mineral to pay with yet
assert "mineral to pay" in main.panel_note.text, main.panel_note.text
common_item = items.item_of(int(items.TIER_CODES[0][0]))
main.inventory.add(common_item, 5)
main.input("1")                                          # Stay
assert main.ctx.respawn == v.stand and main.stats.hp == main.stats.max_hp
assert main.inventory.count(common_item) == 4
# storage: deposit a stack (fee: one common mineral), see it in the village storage, take it back
main.inventory.add(3, 20)
main.input("2")                                          # Back to the main menu ("Back" is option 2 on the inn page)
main.input("2")                                          # Storage
main.input("1")                                          # Deposit
labels = [b.text for b in main.panel_buttons if b.enabled]
idx = next(i for i, t in enumerate(labels) if "Rock" in t)
main.input(str((idx + 1) % 10))
assert main.ctx.book.get(v.id).storage.count(3) == 20 and main.inventory.count(3) == 0, main.panel_note.text
# guide: the boss location; HUD gets a line about him afterwards
main.panel_choose(len([b for b in main.panel_buttons if b.enabled]) - 1)      # Back (to storage)
main.input("3")                                          # Back (storage -> main) is option 3 on the storage page
main.input("4")                                          # Guide
main.input("4")                                          # The Slime King
assert "dig straight down" in main.panel_lines.text.lower(), main.panel_lines.text
assert main.ctx.flags.boss_known
main.input("1")                                          # Back
main.input("5")                                          # Back to the main menu
assert main.panel_title.text.startswith("VILLAGE")
main.input("escape")                                     # Esc leaves
assert main.st.panel is None and main.mouse.locked and not main.panel_ui.enabled
assert all(getattr(main, n).enabled is True for n in HUD)
for _ in range(10):
    main.update()
assert main.st.panel is None, "still standing on the tile: it must not open again"
stand_on(v.x + 3.5, v.ground + 1.01, v.z + 0.5)
main.update()
stand_on(v.x + 0.5, v.ground + 1.01, v.z + 0.5)
main.update()
assert main.st.panel is not None, "stepping off and on again opens it again"
main.input("escape")
main.st.info_timer = 0.0
main.update()
assert "Slime King" in main.hud_info.text, main.hud_info.text

# dying after an inn stay: you wake up on the village tile
main.stats.base = {"hp": 5, "atk": 1, "def": 1, "spd": 1}
main.stats.restore_full()
main.inventory.add(3, 3)
Y3 = platform(130, 40)
put_player(135.5, Y3 + 0.01, 43.5)
run(1500, until=lambda: (135 >> 4, 45 >> 4) in main.manager.meshed)      # slimes only exist in loaded chunks
bitey = main.enemies.add(ActionEnemy(main.world, make_enemy(3, main.rng), 135.5, Y3 + 0.001, 45.0))
bitey.stats.atk = 999
run(400, until=lambda: main.inventory.used_slots() == 0)
main.enemies.kill(bitey)
assert (round(main.body.x, 2), round(main.body.z, 2)) == (round(v.stand[0], 2), round(v.stand[2], 2)), (main.body.x, main.body.z)
assert main.inventory.used_slots() == 0 and "inn" in main.message.text.lower(), main.message.text
assert main.ctx.book.get(v.id).storage.count(3) == 20, "storage survives death"
for _ in range(5):
    main.update()
assert main.st.panel is None, "waking up on the tile must not pop the commands open"
main.stats.base = {"hp": 50, "atk": 10, "def": 6, "spd": 8}
main.stats.restore_full()
print("village: commands opened on the tile, inn/storage/guide worked, respawn at the inn")

# a night at the inn ends in the morning (and a stay by day leaves the time alone)
stand_on(v.x + 3.5, v.ground + 1.01, v.z + 0.5)
main.update()
main.st.world_time = 0.0                                 # midnight
stand_on(v.x + 0.5, v.ground + 1.01, v.z + 0.5)
main.update()
assert main.st.panel is not None
main.stats.take_damage(10)
main.inventory.add(common_item, 3)
main.input("1"); main.input("1")                         # Inn -> Stay
assert "morning" in main.panel_note.text, main.panel_note.text
assert daytime.daylight(main.st.world_time) > 0.9 and abs(daytime.phase(main.st.world_time) - C.START_TIME) < 1e-6, main.st.world_time
main.input("escape")
main.st.sky_key = None
main.st.fog_timer = 0.0
main.update()
assert sum(main.window.color.args[:3]) > 1.5, "the sky is bright again"
stand_on(v.x + 3.5, v.ground + 1.01, v.z + 0.5)
main.update()
stand_on(v.x + 0.5, v.ground + 1.01, v.z + 0.5)
main.update()
assert main.st.panel is not None and not daytime.is_night(main.st.world_time)
t_day = main.st.world_time                               # (no frames run while the screen is open)
main.stats.take_damage(10)
main.input("1"); main.input("1")
assert main.st.world_time == t_day, "a stay by day does not move the clock"
main.input("escape")
print("inn at night: slept until morning (%s)" % daytime.clock_text(main.st.world_time))

# ---- the Slime King: a big room deep underground; within 4 blocks he chases you, every hit changes his colour
from blocks import ROCK as _ROCK     # noqa: E402
ax, az = boss_arena.arena_center(main.world.seed)
fy = boss_arena.arena_floor_y(main.world.seed)
H_ = C.ARENA_HALF
assert main.world.get_block(ax, fy, az) == WOOD, "the Wood tile is in the middle of the floor"
assert main.world.get_block(ax + H_, fy + 1, az - H_) == AIR and main.world.get_block(ax, fy + C.ARENA_HEIGHT, az) == AIR, "41 x 41 x 16 room"
assert main.world.get_block(ax, fy + C.ARENA_HEIGHT + 1, az) == _ROCK and main.world.get_block(ax + H_ + 1, fy + 3, az) == _ROCK, "solid walls and ceiling"
assert fy + C.ARENA_HEIGHT + 1 < C.SEA_LEVEL, "the lair is underground"
stand_on(ax + 15.5, fy + 1.01, az + 0.5)
run(3000, until=lambda: main.enemies.boss() is not None)
boss = main.enemies.boss()
assert boss is not None and boss.size == C.BOSS_SIZE and boss.stats.level == C.BOSS_LEVEL
bx, bz = boss.x, boss.z
run(60)
assert not boss.chasing and abs(boss.x - bx) < 1e-6, "the King stands still while you are more than 4 blocks away"
stand_on(boss.x + 3.5, fy + 1.01, boss.z)
run(25)
assert boss.chasing, "within 4 blocks the King chases you"
stand_on(boss.x + 9.0, fy + 1.01, boss.z)
run(10)
assert not boss.chasing, "you can run away from the King"
main.stats.base = {"hp": 4000, "atk": 400, "def": 400, "spd": 400}
main.stats.restore_full()
stand_on(boss.x + 3.0, fy + 1.01, boss.z)
run(120)
first_color, hp_boss = tuple(boss.stats.color), boss.stats.max_hp
fake.held_keys["left mouse"] = 1.0
hp_before = boss.stats.hp
for _ in range(600):
    aim_at(boss)
    main.update()
    if boss.stats.hp < hp_before:
        break
assert boss.stats.hp < hp_before and hp_before - boss.stats.hp <= round(hp_boss * C.BOSS_DAMAGE_CAP), "per-hit damage cap"
assert tuple(boss.stats.color) != first_color, "the Slime King changes colour every time he is hit"
for _ in range(9000):
    if not boss.alive:
        break
    aim_at(boss)
    main.update()
fake.held_keys["left mouse"] = 0.0
assert not boss.alive and main.ctx.flags.boss_defeated and main.world.extended and main.enemies.boss_defeated
assert "rumbles" in main.message.text, main.message.text
run(120)
assert main.enemies.boss() is None, "he does not come back"
# afterwards: enemies lose the level cap and use wider colours; villages offer services
main.rng = random.Random(3)
main.stats.base = {"hp": 400, "atk": 60, "def": 30, "spd": 30}
main.stats.restore_full()
stand_on(v.x + 3.5, v.ground + 1.01, v.z + 0.5)
main.update()
stand_on(v.x + 0.5, v.ground + 1.01, v.z + 0.5)
main.update()
assert "Services" in [b.text.split(") ", 1)[-1] for b in main.panel_buttons if b.enabled], [b.text for b in main.panel_buttons if b.enabled]
main.input("escape")
main.stats.base = {"hp": 50, "atk": 10, "def": 6, "spd": 8}
main.stats.restore_full()
stand_on(*main.SPAWN)
main.st.last_xz = (main.body.x, main.body.z)
print("boss: lair, chase at 4 blocks, colour change per hit, fight won, world in its post-boss state")

# ---- save / reload round trip through main.py itself
placed_cell = None
sx, sy, sz = main.SPAWN
main.body.x, main.body.z = sx + 3, sz + 3
main.body.y = main.world.surface_y(int(sx + 3), int(sz + 3)) + 1.01
main.body.vy = 0.0
for _ in range(20):
    main.update()
main.inventory.add(ROCK, 7)
slot = next(i for i, sl in enumerate(main.inventory.slots) if sl and sl[0] == ROCK)
main.input(str(slot + 1) if slot < 9 else "0")
fake.camera.forward = Fake(x=0.0, y=-0.6, z=0.8)        # the ground ahead (straight down would target our own cell)
main.update()
placed_cell = main.st.hit.prev
main.input("right mouse down")
assert main.world.get_block(*placed_cell) == ROCK, "placement failed"
time_before = main.st.world_time
stats_before = (main.stats.level, main.stats.hp, main.stats.color)
pos_before = (main.body.x, main.body.y, main.body.z)
inv_before = [list(x) if x else None for x in main.inventory.slots]

# ---- Esc opens the menu; the world stands still while it is open
main.input("escape")
assert main.st.paused and main.menu.enabled
assert "Smoke Mod" in main.menu_mods.text and "problem" in main.menu_mods.text, main.menu_mods.text
frozen = (main.body.x, main.body.y, main.body.z)
fake.held_keys["w"] = 1.0
for _ in range(30):
    main.update()
assert (main.body.x, main.body.y, main.body.z) == frozen, "player moved while paused"
count = main.inventory.count(ROCK)
main.input("right mouse down")
main.input("q")
assert main.inventory.count(ROCK) == count, "game input leaked through the menu"
fake.held_keys["w"] = 0.0

# ---- Save button
main.menu_save()
assert main.menu_status.text == "Game saved", main.menu_status.text
assert os.path.exists(os.path.join(_tmp, "save", "meta.json"))
print("saved; chunk files:", sorted(os.listdir(os.path.join(_tmp, "save", "chunks"))))

# ---- change things, then Load button must roll them back
main.world.set_block(*placed_cell, 0)
main.inventory.add(ROCK, 3)
main.body.x += 5
main.menu_load()
assert not main.st.paused and not main.menu.enabled, "menu should close after loading"
assert main.world.get_block(*placed_cell) == ROCK, "Load did not restore the saved block"
assert [list(x) if x else None for x in main.inventory.slots] == inv_before, "Load did not restore the inventory"
assert abs(main.body.x - pos_before[0]) < 1e-6
assert (main.stats.level, main.stats.hp, main.stats.color) == stats_before, "HP/colour not restored by Load"
assert main.message.text == "Save loaded"
fake.held_keys["left mouse"] = 1.0                      # still "held" from clicking the menu button
main.update()
assert main.miner.progress == 0.0, "dig button held from a menu click must not start digging"
fake.held_keys["left mouse"] = 0.0
main.update()
print("menu: pause, save, load-with-rollback OK")

# ---- Load with no save file reports instead of crashing
import shutil
tmp_store_dir = os.path.join(_tmp, "save")
shutil.move(tmp_store_dir, tmp_store_dir + "_hidden")
main.input("escape")
main.menu_load()
assert main.st.paused and main.menu_status.text == "No save to load", main.menu_status.text
shutil.move(tmp_store_dir + "_hidden", tmp_store_dir)
main.input("escape")
assert not main.st.paused

# ---- Save and quit
main.input("escape")
main.menu_end()
assert quit_calls, "Save and quit did not quit"
main.input("escape")

fake.held_keys["w"] = 0.0
fake.held_keys["space"] = 0.0
main = importlib.reload(main)                  # = starting the game again
main.rng = random.Random(2)
assert main.world.get_block(*placed_cell) == ROCK, "placed block lost after reload"
assert [list(x) if x else None for x in main.inventory.slots] == inv_before, "inventory differs after reload"
assert (main.stats.level, main.stats.hp, main.stats.color) == stats_before, "HP/colour differ after reload"
assert main.ctx.flags.boss_defeated and main.ctx.flags.boss_known and main.world.extended, "flags lost on reload"
assert main.ctx.respawn == villages.village_in_region(main.world.seed, 0, 0).stand, "inn respawn point lost on reload"
assert main.ctx.book.get("0,0").storage.count(3) == 20, "village storage lost on reload"
assert abs(main.st.world_time - time_before) < 2.0, "time of day not restored after reload"   # a few frames pass before the last save
assert main.st.world_time > 1.0, "a restored game must not start the clock from zero"
assert abs(main.body.x - pos_before[0]) < 1e-6 and abs(main.body.z - pos_before[2]) < 1e-6
assert main.message.text.startswith("Save loaded"), main.message.text            # (the MOD notice follows it)
print("reloaded: block, inventory and position restored")


# ---- a brand new game gets a brand new random map (asked through the menu, with a yes/no question)
old_seed = main.world.seed
main.save_now(False)
main.input("escape")
main.menu_new_world()
assert main.st.panel is not None and main.panel_title.text == "NEW WORLD" and not main.st.paused
main.input("2")                                          # No
assert main.world.seed == old_seed and main.st.panel is None
main.input("escape")
assert str(old_seed) in main.menu_seed.text, main.menu_seed.text
main.menu_new_world()
main.input("1")                                          # Yes
assert main.world.seed != old_seed and main.st.panel is None and not main.st.paused
assert str(main.world.seed) in main.message.text and main.inventory.used_slots() == 0 and main.stats.level == 1
assert any("backup" in n for n in os.listdir(_tmp)), os.listdir(_tmp)
assert abs(daytime.phase(main.st.world_time) - C.START_TIME) < 1e-6
assert main.world.get_block(int(main.body.x // 1), int(main.body.y - 1.01 + 0.5), int(main.body.z // 1)) == 2, "starts on grass"
print("new world: seed %d -> %d, old game kept as a backup" % (old_seed, main.world.seed))
main.save_now(False)

# A corrupt save must not stop the game from starting.
(Path(_tmp) / "save" / "meta.json").write_text("{broken")
main = importlib.reload(main)
assert "unreadable" in main.message.text
assert main.world.get_block(*placed_cell) != ROCK, "corrupt save must start a fresh world"
assert any("corrupt" in n for n in os.listdir(_tmp)), "corrupt save should be set aside, not deleted"
print("corrupt save handled; message:", repr(main.message.text))
print("SMOKE OK")
