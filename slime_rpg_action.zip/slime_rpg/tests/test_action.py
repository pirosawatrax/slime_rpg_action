"""Stage 9 tests: action combat rules, slime placement, chasing / standing still / steps, night, the Slime King's colour."""
import math
import random
import unittest

import config as C
import items
from blocks import AIR, ROCK, WOOD, WATER
from game import combat
from game.battle import make_boss, make_enemy
from game.enemies import ActionEnemy, EnemyManager
from game.physics import Body
from game.stats import PlayerStats
from world import enemy_spawn
from world.world import World


def flat_world(w=16, d=16, floor_y=10, block=ROCK):
    """A world of our own: a stone slab at floor_y, free air above, no terrain generation."""
    world = World(1, generator=lambda seed, cx, cz: __import__("numpy").zeros((16, C.WORLD_HEIGHT, 16), dtype="uint8"))
    for x in range(w):
        for z in range(d):
            world.set_block(x, floor_y, z, block)
    return world


class TestDamage(unittest.TestCase):
    def setUp(self):
        self.rng = random.Random(3)
        self.stats = PlayerStats()
        self.stats.color = (200, 60, 60)

    def test_tackle_uses_the_old_formula_and_the_colour_cycle(self):
        green, blue = make_enemy(3, self.rng), make_enemy(3, self.rng)
        green.color, blue.color = (60, 200, 60), (60, 60, 200)
        # red beats blue, green beats red (the same cycle as the turn-based game)
        strong, weak = combat.tackle_damage(self.stats, blue, random.Random(1))[0], combat.tackle_damage(self.stats, green, random.Random(1))[0]
        self.assertGreater(strong, weak)
        self.assertEqual(combat.tag(combat.tackle_multiplier(self.stats, blue)), combat.TAG_STRONG)
        self.assertEqual(combat.tag(combat.tackle_multiplier(self.stats, green)), combat.TAG_WEAK)

    def test_bite_is_at_least_one(self):
        e = make_enemy(1, self.rng)
        e.atk = 0
        self.assertGreaterEqual(combat.bite_damage(self.stats, e, self.rng)[0], 1)

    def test_mineral_hit_consumes_and_heals_when_weak(self):
        e = make_enemy(3, self.rng)
        e.color = (60, 60, 200)
        good = items.item_of(items.code_from_rgb((220, 40, 40)))     # red beats blue
        before = e.hp
        res = combat.apply_hit("mineral", self.stats, e, random.Random(2), item=good)
        self.assertTrue(res.consumed)
        self.assertLess(e.hp, before)
        e2 = make_enemy(3, self.rng)
        e2.color = (220, 40, 40)
        e2.hp = e2.max_hp - 5
        bad = items.item_of(items.code_from_rgb((40, 40, 220)))      # blue loses to red (it cures the slime)
        res2 = combat.apply_hit("mineral", self.stats, e2, random.Random(2), item=bad)
        self.assertTrue(res2.consumed)
        self.assertGreaterEqual(e2.hp, e2.max_hp - 5)                 # never lower than before

    def test_boss_hit_is_capped_and_xp_is_tripled(self):
        boss = make_boss(self.rng)
        self.stats.base = {"hp": 400, "atk": 900, "def": 30, "spd": 30}
        res = combat.apply_hit("tackle", self.stats, boss, self.rng, boss=True)
        self.assertLessEqual(res.damage, round(boss.max_hp * C.BOSS_DAMAGE_CAP))
        xp_boss, _ = combat.reward(PlayerStats(), boss, self.rng, boss=True)
        xp_plain, _ = combat.reward(PlayerStats(), boss, self.rng, boss=False)
        self.assertEqual(xp_boss, int(round(xp_plain * C.BOSS_XP_MULT)))

    def test_boss_colour_always_moves_far_enough(self):
        rng = random.Random(4)
        c = (100, 100, 100)
        from game import colors
        for _ in range(50):
            n = combat.boss_recolor(rng, c)
            self.assertGreaterEqual(colors.distance(n, c), C.BOSS_COLOR_MIN_DISTANCE)
            c = n


class FakeSlime:
    def __init__(self, x, y, z, size=0.9, alive=True):
        self.x, self.y, self.z, self.size, self.alive = x, y, z, size, alive

    def center(self):
        return (self.x, self.y + self.size / 2, self.z)


class TestAiming(unittest.TestCase):
    def setUp(self):
        self.world = flat_world()
        self.eye = (8.5, 11.62, 4.5)

    def test_ray_must_pass_close_to_the_slime_and_within_reach(self):
        near = FakeSlime(8.5, 11.0, 6.0)
        far = FakeSlime(8.5, 11.0, 12.0)
        look = (0.0, -0.1, 1.0)
        self.assertIs(combat.find_target(self.world.get_block, [near], self.eye, look), near)
        self.assertIsNone(combat.find_target(self.world.get_block, [far], self.eye, look), "out of reach")
        self.assertIsNone(combat.find_target(self.world.get_block, [near], self.eye, (1.0, 0.0, 0.0)), "looking elsewhere")

    def test_nearest_wins_and_a_wall_blocks(self):
        a, b = FakeSlime(8.5, 11.0, 6.0), FakeSlime(8.5, 11.0, 6.9)
        self.assertIs(combat.find_target(self.world.get_block, [b, a], self.eye, (0.0, -0.1, 1.0)), a)
        self.world.set_block(8, 11, 5, ROCK)
        self.world.set_block(8, 12, 5, ROCK)
        self.assertIsNone(combat.find_target(self.world.get_block, [a], self.eye, (0.0, -0.1, 1.0)), "a block in the way")

    def test_dead_slimes_are_ignored(self):
        self.assertIsNone(combat.find_target(self.world.get_block, [FakeSlime(8.5, 11.0, 6.0, alive=False)], self.eye, (0, -0.1, 1)))


class TestChase(unittest.TestCase):
    def setUp(self):
        self.world = flat_world(30, 30)
        self.rng = random.Random(2)
        self.player = Body(self.world, 15.5, 11.001, 15.5)

    def slime(self, dx, dz, **kw):
        return ActionEnemy(self.world, make_enemy(3, self.rng), 15.5 + dx, 11.001, 15.5 + dz, **kw)

    def sim(self, e, seconds, safe=False):
        bites = 0
        for _ in range(int(seconds * 60)):
            bites += bool(e.update(1 / 60, self.player, safe, 8))
        return bites

    def test_stands_still_beyond_four_blocks_and_wakes_within_four(self):
        far, near = self.slime(5.0, 0), self.slime(0, 3.5)
        self.sim(far, 2)
        self.assertEqual((far.x, far.z), (20.5, 15.5))
        self.assertFalse(far.chasing)
        self.sim(near, 0.5)
        self.assertTrue(near.chasing)
        self.assertLess(near.z, 15.5 + 3.5 - 0.3)

    def test_it_stops_again_when_you_walk_away(self):
        e = self.slime(0, 3.0)
        self.sim(e, 0.5)
        self.assertTrue(e.chasing)
        self.player.x = 15.5 + 12.0
        self.sim(e, 0.2)
        self.assertFalse(e.chasing)
        x = e.x
        self.sim(e, 1.0)
        self.assertEqual(e.x, x)

    def test_it_bites_about_once_per_interval_and_never_on_wood(self):
        e = self.slime(0, 2.0)
        n = self.sim(e, 5.0)
        self.assertTrue(3 <= n <= 5, n)
        e2 = self.slime(2.0, 0)
        self.assertEqual(self.sim(e2, 5.0, safe=True), 0)

    def test_one_block_up_yes_two_blocks_no(self):
        for x in range(18, 30):
            for z in range(0, 30):
                self.world.set_block(x, 11, z, ROCK)                    # a ledge one block high
        e = ActionEnemy(self.world, make_enemy(3, self.rng), 16.5, 11.001, 15.5)
        self.player.x, self.player.y = 20.5, 12.001
        self.player.vy = 0.0
        self.sim(e, 4)
        self.assertGreater(e.y, 11.9, "climbs one block")
        for x in range(18, 30):
            for z in range(0, 30):
                self.world.set_block(x, 12, z, ROCK)                    # now two blocks
        e2 = ActionEnemy(self.world, make_enemy(3, self.rng), 16.5, 11.001, 15.5)
        self.player.y = 13.001
        self.sim(e2, 4)
        self.assertLess(e2.y, 11.5)
        self.assertLess(e2.x, 18.0, "it stays in front of the wall")

    def test_a_drop_of_two_blocks_stops_it_but_one_is_fine(self):
        for z in range(0, 30):
            for x in range(18, 30):
                self.world.set_block(x, 10, z, AIR)                     # the floor is gone: a drop of one
        e = self.slime(0, 0)
        self.assertEqual(e.step_to(18.5, 15.5), None, "a hole two blocks deep (nothing below)")
        for x in range(18, 30):
            for z in range(0, 30):
                self.world.set_block(x, 9, z, ROCK)
        self.assertEqual(e.step_to(19.5, 15.5), -1, "a one block drop is allowed")

    def test_knock_back_pushes_away_and_flashes(self):
        e = self.slime(0, 1.5)
        z0 = e.z
        e.knock_back(self.player.x, self.player.z)
        self.sim(e, 0.3)
        self.assertGreater(e.z, z0 + 0.3)
        self.assertGreater(e.flash, -1)

    def test_water_is_not_walkable(self):
        for x in range(16, 22):
            for z in range(14, 17):
                self.world.set_block(x, 10, z, WATER)
        e = self.slime(-1, 0)
        self.assertIsNone(e.step_to(17.5, 15.5))


class TestPlacement(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.world = World(C.SEED)

    def test_every_spot_is_solid_ground_with_free_air_above(self):
        count = 0
        for cx in range(-5, 6):
            for cz in range(-5, 6):
                for spot in enemy_spawn.base_spots(self.world, cx, cz, avoid=(0.5, 0.5)) + enemy_spawn.night_spots(self.world, cx, cz, 0):
                    count += 1
                    w = self.world
                    self.assertTrue(enemy_spawn.valid_spot(w, spot.x, spot.y, spot.z), spot)
                    self.assertNotEqual(w.get_block(spot.x, spot.y - 1, spot.z), WATER)
                    self.assertEqual([w.get_block(spot.x, spot.y + i, spot.z) for i in range(3)], [AIR] * 3)
        self.assertGreater(count, 100)

    def test_same_seed_same_spots_and_night_has_more(self):
        a = enemy_spawn.base_spots(self.world, 2, 3)
        self.assertEqual(a, enemy_spawn.base_spots(self.world, 2, 3))
        night_total = sum(len(enemy_spawn.night_spots(self.world, cx, cz, 0)) for cx in range(-4, 5) for cz in range(-4, 5))
        day_surface = sum(1 for cx in range(-4, 5) for cz in range(-4, 5) for s in enemy_spawn.base_spots(self.world, cx, cz) if s.surface)
        self.assertGreater(night_total, day_surface * 0.5)
        self.assertTrue(all(s.night_only for cx in range(-2, 3) for cz in range(-2, 3) for s in enemy_spawn.night_spots(self.world, cx, cz, 0)))

    def test_not_in_the_start_area_villages_or_the_lair(self):
        from world import boss_arena, villages
        for cx in range(-4, 5):
            for cz in range(-4, 5):
                for s in enemy_spawn.base_spots(self.world, cx, cz, avoid=(0.5, 0.5)):
                    self.assertGreaterEqual(math.hypot(s.x + 0.5 - 0.5, s.z + 0.5 - 0.5), C.ENEMY_SPAWN_FREE_RADIUS)
        ax, az = boss_arena.arena_center(C.SEED)
        for cx in range((ax >> 4) - 3, (ax >> 4) + 4):
            for cz in range((az >> 4) - 3, (az >> 4) + 4):
                for s in enemy_spawn.base_spots(self.world, cx, cz):
                    self.assertFalse(boss_arena.arena_contains(C.SEED, s.x, s.z, margin=1), s)
        v = villages.village_in_region(C.SEED, 0, 0)
        for s in enemy_spawn.base_spots(self.world, v.x >> 4, v.z >> 4):
            self.assertFalse(abs(s.x - v.x) <= C.VILLAGE_HALF and abs(s.z - v.z) <= C.VILLAGE_HALF)


class TestManager(unittest.TestCase):
    def test_chunks_spawn_and_vanish_and_the_king_appears_once(self):
        world = World(C.SEED)
        mgr = EnemyManager(world, random.Random(1), origin=(0.5, 0.5))
        removed_log = []
        mgr.on_remove = removed_log.append
        loaded = {(cx, cz) for cx in range(-2, 3) for cz in range(-2, 3)}
        for _ in range(40):
            mgr.sync(loaded, 0.5 * C.DAY_LENGTH, (0.5, 0.5))
        n = len(mgr.enemies)
        self.assertGreater(n, 5)
        mgr.sync(set(), 0.5 * C.DAY_LENGTH, (0.5, 0.5))
        self.assertEqual(mgr.enemies, [])
        self.assertEqual(len(removed_log), n)
        from world import boss_arena
        bx, _, bz = boss_arena.boss_start(C.SEED)
        key = (math.floor(bx) >> 4, math.floor(bz) >> 4)
        mgr.sync({key}, 0.5 * C.DAY_LENGTH, (bx, bz))
        mgr.sync({key}, 0.5 * C.DAY_LENGTH, (bx, bz))
        kings = [e for e in mgr.enemies if e.boss]
        self.assertEqual(len(kings), 1)
        self.assertEqual(kings[0].size, C.BOSS_SIZE)
        mgr.kill(kings[0])
        mgr.boss_defeated = True
        mgr.sync({key}, 0.5 * C.DAY_LENGTH, (bx, bz))
        self.assertIsNone(mgr.boss())

    def test_night_extras_fade_at_dawn(self):
        world = World(C.SEED)
        mgr = EnemyManager(world, random.Random(1), origin=(0.5, 0.5))
        loaded = {(cx, cz) for cx in range(-2, 3) for cz in range(-2, 3)}
        for _ in range(60):
            mgr.sync(loaded, 0.5 * C.DAY_LENGTH, (0.5, 0.5))
        day = len(mgr.enemies)
        for _ in range(60):
            mgr.sync(loaded, 0.0, (0.5, 0.5))
        self.assertGreater(len(mgr.enemies), day)
        mgr.sync(loaded, 0.5 * C.DAY_LENGTH + C.DAY_LENGTH, (0.5, 0.5))
        self.assertFalse(any(e.night_only and math.hypot(e.x, e.z) > C.ENEMY_NIGHT_DESPAWN_DISTANCE for e in mgr.enemies))


if __name__ == "__main__":
    unittest.main()
