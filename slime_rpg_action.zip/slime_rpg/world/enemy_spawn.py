"""Where enemy slimes stand (design: action combat). Engine-free, deterministic: the same seed and chunk always give the same
spots (night extras also depend on the day number). A spot is only ever accepted when the slime would be fully visible:
solid ground under it, and free air in its cell and the two cells above, so no slime is sunk into the ground or into a wall."""
import math
import random
from dataclasses import dataclass

import config as C
from blocks import AIR, BLOCKS, WATER
from world import boss_arena, villages
from world.worldgen_heights import surface_heights

S = C.CHUNK_SIZE
H = C.WORLD_HEIGHT


@dataclass(frozen=True)
class Spot:
    x: int                 # the cell the slime stands in (its feet are at the bottom of this cell)
    y: int
    z: int
    surface: bool          # on the ground above (True) or in a cave (False)
    night_only: bool = False


def chunk_rng(seed, cx, cz, salt=0):
    return random.Random((seed * 1000003 ^ cx * 73856093 ^ cz * 19349663 ^ salt * 83492791 ^ 0x5EED) & 0xFFFFFFFF)


def solid_floor(world, x, y, z):
    """True if the block at (x, y, z) is a ground a slime may stand on: solid, not water, not a tree part or a plant."""
    block = world.get_block(x, y, z)
    if block == AIR or block == WATER:
        return False
    info = BLOCKS.get(block)
    return info is not None and info.sound in ("soft", "rock")


def cell_is_free(world, x, y, z, height=3):
    """`height` free air cells from y upwards (a slime and the room it needs above it)."""
    return all(world.get_block(x, y + i, z) == AIR for i in range(height))


def valid_spot(world, x, y, z):
    """The one rule that keeps slimes out of walls and ground: solid ground below, free air at the cell and above it."""
    return 1 <= y < H - 3 and solid_floor(world, x, y - 1, z) and cell_is_free(world, x, y, z)


def _blocked(seed, x, z, avoid):
    if boss_arena.arena_contains(seed, x, z, margin=2):
        return True
    if avoid is not None and math.hypot(x + 0.5 - avoid[0], z + 0.5 - avoid[1]) < C.ENEMY_SPAWN_FREE_RADIUS:
        return True
    return False


def _near_village(seed, cx, cz, x, z):
    m = C.VILLAGE_HALF + C.ENEMY_VILLAGE_MARGIN
    return any(abs(x - v.x) <= m and abs(z - v.z) <= m for v in villages.villages_near_chunk(seed, cx, cz, pad=m))


def _surface_spot(world, rng, cx, cz, avoid):
    x, z = cx * S + rng.randrange(S), cz * S + rng.randrange(S)
    if _blocked(world.seed, x, z, avoid) or _near_village(world.seed, cx, cz, x, z):
        return None
    top = world.surface_y(x, z)
    if top < C.SEA_LEVEL or not valid_spot(world, x, top + 1, z):
        return None
    return Spot(x, top + 1, z, True)


def _cave_spot(world, rng, cx, cz, avoid):
    x, z = cx * S + rng.randrange(S), cz * S + rng.randrange(S)
    if _blocked(world.seed, x, z, avoid) or _near_village(world.seed, cx, cz, x, z):
        return None
    top = max(int(surface_heights(world.seed, x, z)), C.SEA_LEVEL)
    options = [y for y in range(2, top - 3) if valid_spot(world, x, y, z)]
    return Spot(x, rng.choice(options), z, False) if options else None


def base_spots(world, cx, cz, avoid=None):
    """The slimes that stand in this chunk by day (and by night): a few on the ground, more in caves."""
    rng = chunk_rng(world.seed, cx, cz)
    out, taken = [], set()
    for _ in range(C.ENEMY_SURFACE_ATTEMPTS):
        roll = rng.random()
        spot = _surface_spot(world, rng, cx, cz, avoid)
        if spot is not None and roll < C.ENEMY_SURFACE_CHANCE and (spot.x, spot.z) not in taken:
            taken.add((spot.x, spot.z))
            out.append(spot)
    for _ in range(C.ENEMY_CAVE_ATTEMPTS):
        roll = rng.random()
        spot = _cave_spot(world, rng, cx, cz, avoid)
        if spot is not None and roll < C.ENEMY_CAVE_CHANCE and (spot.x, spot.y, spot.z) not in taken:
            taken.add((spot.x, spot.y, spot.z))
            out.append(spot)
    return out


def night_spots(world, cx, cz, day, avoid=None):
    """Extra slimes on the ground at night, so the surface is about NIGHT_ENCOUNTER_MULT times as busy. They fade at dawn."""
    chance = min(1.0, C.ENEMY_SURFACE_CHANCE * (C.NIGHT_ENCOUNTER_MULT - 1.0))
    rng = chunk_rng(world.seed, cx, cz, salt=1 + int(day))
    out = []
    for _ in range(C.ENEMY_SURFACE_ATTEMPTS):
        roll = rng.random()
        spot = _surface_spot(world, rng, cx, cz, avoid)
        if spot is not None and roll < chance:
            out.append(Spot(spot.x, spot.y, spot.z, True, night_only=True))
    return out
