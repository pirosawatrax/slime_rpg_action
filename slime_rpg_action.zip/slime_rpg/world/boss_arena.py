"""Where the boss lives (design 6.4: deep underground). One fixed spot per seed, a few hundred blocks from the origin:
a big room (41 x 41, 16 high) buried in solid rock, with its floor at a seed-picked height near the bottom of the world
and a single Wood tile in the middle where the Slime King waits. You dig down to it (the guide in a village tells you
where); there is no door and no prompt: step within 4 blocks of the King and the fight is on. Engine-free."""
import math
from functools import lru_cache

import config as C
from blocks import AIR, ROCK, WOOD
from world.noise import hash2
from world.worldgen_heights import surface_heights

HALF = C.ARENA_HALF
HEIGHT = C.ARENA_HEIGHT
SHELL = C.ARENA_SHELL
REACH = HALF + SHELL                  # how far from the centre the structure (room + rock shell) extends


@lru_cache(maxsize=64)
def arena_center(seed):
    """(x, z) of the Wood tile. The first of a few hashed spots that lies on dry land."""
    lo, hi = C.BOSS_DISTANCE
    for k in range(32):
        angle = float(hash2(k * 7 + 1, 3, seed + 8101)) * 2 * math.pi
        dist = lo + float(hash2(k * 13 + 2, 5, seed + 8102)) * (hi - lo)
        x, z = int(round(math.cos(angle) * dist)), int(round(math.sin(angle) * dist))
        if int(surface_heights(seed, x, z)) >= C.SEA_LEVEL + 1:
            return x, z
    return int(hi), 0


@lru_cache(maxsize=64)
def arena_floor_y(seed):
    """Y of the room's floor (the Wood tile is part of it): a seed-picked value in C.ARENA_FLOOR_Y."""
    lo, hi = C.ARENA_FLOOR_Y
    return min(hi, lo + int(float(hash2(17, 29, seed + 8103)) * (hi - lo + 1)))


def boss_start(seed):
    """(x, y, z) where the Slime King stands: on the Wood tile, in the middle of the room."""
    ax, az = arena_center(seed)
    return ax + 0.5, arena_floor_y(seed) + 1.0, az + 0.5


def arena_at(seed, x, z):
    """True if this column is the Wood tile."""
    return (x, z) == arena_center(seed)


def arena_contains(seed, x, z, margin=0):
    """True if the column lies inside the room, its rock shell and `margin` more blocks."""
    ax, az = arena_center(seed)
    return abs(x - ax) <= REACH + margin and abs(z - az) <= REACH + margin


def arena_near_chunk(seed, cx, cz):
    """The arena centre if the room (with its shell) touches this chunk, else None."""
    ax, az = arena_center(seed)
    x0, z0 = cx * C.CHUNK_SIZE, cz * C.CHUNK_SIZE
    if x0 - REACH <= ax < x0 + C.CHUNK_SIZE + REACH and z0 - REACH <= az < z0 + C.CHUNK_SIZE + REACH:
        return ax, az
    return None


@lru_cache(maxsize=8)
def _structure(floor_y):
    out = {}
    lo, hi = floor_y - SHELL, floor_y + HEIGHT + SHELL
    for dx in range(-REACH, REACH + 1):
        for dz in range(-REACH, REACH + 1):
            inside = abs(dx) <= HALF and abs(dz) <= HALF
            for y in range(max(0, lo), hi + 1):
                out[(dx, y, dz)] = AIR if inside and floor_y < y <= floor_y + HEIGHT else ROCK
    out[(0, floor_y, 0)] = WOOD
    for sx in (-6, 6):                                  # four short Wood posts: something to dodge around
        for sz in (-6, 6):
            for y in (1, 2, 3):
                out[(sx, floor_y + y, sz)] = WOOD
    return out


def structure_blocks(seed):
    """{(dx, y, dz): block} relative to the tile's column, with absolute y: the room (air), a solid rock shell all around
    it, the Wood tile in the floor and four Wood posts. Do not modify the returned dict."""
    return _structure(arena_floor_y(seed))
