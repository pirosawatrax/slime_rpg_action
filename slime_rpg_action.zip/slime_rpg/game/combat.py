"""Action combat rules (engine-free): who the player is aiming at, what a hit does, what a bite does, experience.
All damage maths is the old turn-based maths (game/battle.py), so levels, colours and experience are unchanged;
this module only decides WHEN and WHO. Used by game/enemies.py and main.py."""
import math
from dataclasses import dataclass, field

import config as C
import items
from game import colors, progression
from game.battle import base_damage, throw_value, random_color

TAG_STRONG, TAG_WEAK = "strong", "weak"


def tag(multiplier):
    """'strong' / 'weak' / '' for a colour multiplier (the same thresholds the old battle screen used)."""
    return TAG_STRONG if multiplier >= 1.15 else (TAG_WEAK if multiplier <= 0.85 else "")


@dataclass
class HitResult:
    """What one of your attacks did to one enemy."""
    kind: str                       # 'tackle' | 'mineral'
    damage: int = 0                 # HP taken from the enemy
    healed: int = 0                 # HP the enemy got back (a weak colour thrown... used on it)
    consumed: bool = False          # a mineral was used up
    multiplier: float = 1.0
    killed: bool = False
    xp: int = 0
    level_ups: list = field(default_factory=list)


def _roll(rng):
    return 1.0 + rng.uniform(-C.DAMAGE_RANDOM, C.DAMAGE_RANDOM)


def _cap(enemy, n, boss):
    """The Slime King never takes more than BOSS_DAMAGE_CAP of his max HP from one hit."""
    return min(n, max(1, int(round(enemy.max_hp * C.BOSS_DAMAGE_CAP)))) if boss else n


def tackle_multiplier(stats, enemy):
    return colors.matchup(stats.color, enemy.color)


def mineral_multiplier(item, enemy):
    return colors.matchup(items.rgb(items.code_of(item)), enemy.color)


def tackle_damage(stats, enemy, rng, boss=False):
    m = tackle_multiplier(stats, enemy)
    n = max(1, int(round(base_damage(C.TACKLE_FRACTION, stats.atk, enemy.defense, enemy.max_hp) * m * _roll(rng))))
    return _cap(enemy, n, boss), m


def mineral_value(stats, enemy, item, rng):
    """Signed result of hitting with a mineral: >= 1 hurts, <= -1 heals, in between nothing happens (as a throw did)."""
    m = mineral_multiplier(item, enemy)
    return base_damage(C.THROW_FRACTION, stats.atk, enemy.defense, enemy.max_hp) * throw_value(m) * _roll(rng), m


def bite_damage(stats, enemy, rng):
    """What an enemy bite takes from you (never below 1)."""
    m = colors.matchup(enemy.color, stats.color)
    n = max(1, int(round(base_damage(C.TACKLE_FRACTION, enemy.atk, stats.defense, stats.max_hp) * m * _roll(rng))))
    return n, m


def apply_hit(kind, stats, enemy, rng, item=None, boss=False):
    """Resolve one connected attack on `enemy` (a game.battle.Enemy) and update its HP. `item` is the mineral in hand for
    kind='mineral'. Does NOT hand out experience (see reward) and does not change the boss colour (see boss_recolor)."""
    res = HitResult(kind)
    if kind == "tackle":
        n, res.multiplier = tackle_damage(stats, enemy, rng, boss)
        enemy.hp -= n
        res.damage = n
    else:
        value, res.multiplier = mineral_value(stats, enemy, item, rng)
        res.consumed = True                                  # it connected, so it is used up whatever it does
        if value >= 1:
            n = _cap(enemy, int(round(value)), boss)
            enemy.hp -= n
            res.damage = n
        elif value <= -1 and enemy.hp < enemy.max_hp:
            n = min(enemy.max_hp - enemy.hp, int(round(-value)))
            enemy.hp += n
            res.healed = n
    res.killed = enemy.hp <= 0
    return res


def reward(stats, enemy, rng, boss=False):
    """Experience for a kill (as before: x3 for the boss) added to the player; returns (xp, [LevelUp])."""
    xp = progression.xp_reward(enemy.level, stats.level)
    if boss:
        xp = int(round(xp * C.BOSS_XP_MULT))
    return xp, stats.add_xp(xp, rng)


def boss_recolor(rng, current, extended=False):
    """The King's next colour: at least BOSS_COLOR_MIN_DISTANCE away from the current one, so a change always matters."""
    best = None
    for _ in range(30):
        c = random_color(rng, extended)
        if colors.distance(c, current) >= C.BOSS_COLOR_MIN_DISTANCE:
            return c
        best = c
    return best


# ---------------------------------------------------------------- aiming
def aim_hit_distance(eye, direction, center, radius, reach):
    """Distance along the aim ray at which a ball of `radius` around `center` is hit, or None when the ray misses it or
    it is farther than `reach` (measured to the ball's surface). `direction` need not be normalised."""
    dx, dy, dz = direction
    n = math.sqrt(dx * dx + dy * dy + dz * dz)
    if n == 0:
        return None
    dx, dy, dz = dx / n, dy / n, dz / n
    vx, vy, vz = center[0] - eye[0], center[1] - eye[1], center[2] - eye[2]
    t = vx * dx + vy * dy + vz * dz                         # how far along the ray the centre's nearest point is
    if t < -radius:
        return None
    px, py, pz = vx - dx * t, vy - dy * t, vz - dz * t
    if px * px + py * py + pz * pz > radius * radius:
        return None
    if math.sqrt(vx * vx + vy * vy + vz * vz) - radius > reach:
        return None
    return max(0.0, t)


def find_target(world_get_block, enemies, eye, direction, reach=None):
    """The enemy under the crosshair within reach (nearest along the ray), or None. A block between you and the slime
    blocks the blow. `enemies` are game.enemies.ActionEnemy objects (they have .center(), .size, .alive)."""
    from game.raycast import raycast
    reach = C.PLAYER_ATTACK_RANGE if reach is None else reach
    best, best_t = None, None
    for e in enemies:
        if not e.alive:
            continue
        radius = e.size / 2 + C.AIM_RADIUS_EXTRA
        t = aim_hit_distance(eye, direction, e.center(), radius, reach)
        if t is None or (best_t is not None and t >= best_t):
            continue
        if t > 0 and raycast(world_get_block, eye, direction, t) is not None:
            continue                                         # a wall in the way
        best, best_t = e, t
    return best
