"""Enemy slimes as things standing in the world (action combat). Engine-free: main.py draws them and feeds in the player.

ActionEnemy  one slime (or the Slime King): stands still until you come within ENEMY_CHASE_DISTANCE, then walks at you,
             climbs or drops at most one block (anything bigger stops it), bites when it reaches you, gets knocked back.
EnemyManager creates them from world.enemy_spawn when a chunk is loaded, drops them when it is unloaded, adds night-only
             extras after dark, and runs every slime that is near enough to matter."""
import math

import config as C
from blocks import AIR, WOOD
from game import combat, daytime, progression
from game.battle import make_boss, make_enemy
from game.physics import Body
from world import boss_arena, enemy_spawn
from world.worldgen_heights import surface_heights


class ActionEnemy:
    def __init__(self, world, stats, x, y, z, boss=False, night_only=False, chunk=None):
        self.stats = stats                        # a game.battle.Enemy: level, hp, atk, defense, spd, color, name
        self.boss = boss
        self.size = C.BOSS_SIZE if boss else C.ENEMY_SIZE
        self.night_only = night_only
        self.chunk = chunk
        self.body = Body(world, x, y + 0.001, z)
        self.body.hw = self.size / 2
        self.body.h = self.size
        self.world = world
        self.alive = True
        self.chasing = False
        self.attack_timer = C.ENEMY_FIRST_ATTACK_DELAY
        self.flash = 0.0                          # seconds of white flash left
        self.knock_t = 0.0
        self.knock_vx = self.knock_vz = 0.0
        self.facing = 0.0                         # degrees, for the eyes
        self.entity = None                        # the drawn thing (owned by main.py)

    # ---- geometry -----------------------------------------------------
    x = property(lambda self: self.body.x)
    y = property(lambda self: self.body.y)
    z = property(lambda self: self.body.z)

    def center(self):
        return (self.body.x, self.body.y + self.size / 2, self.body.z)

    def cells_high(self):
        return max(1, int(math.ceil(self.size - 1e-9)))

    # ---- movement rules -----------------------------------------------
    def step_to(self, x, z):
        """The step (+1 up, 0 level, -1 down) needed to walk to column (x, z), or None when it is not allowed: a wall or a
        drop of more than ENEMY_MAX_STEP blocks, or water. The slime then simply stays where it is."""
        w = self.world
        cx, cz = math.floor(x), math.floor(z)
        y0 = math.floor(self.body.y)
        m = C.ENEMY_MAX_STEP
        for d in [0] + list(range(1, m + 1)) + [-k for k in range(1, m + 1)]:
            y = y0 + d
            if y < 1:
                continue
            if all(not w.is_blocking(cx, y + i, cz) for i in range(self.cells_high())) and w.is_blocking(cx, y - 1, cz):
                return d
        return None

    def speed(self, player_spd):
        lo, hi = C.ENEMY_SPEED_RATIO
        return C.ENEMY_SPEED_BASE * max(lo, min(hi, self.stats.spd / max(1, player_spd)))

    def knock_back(self, from_x, from_z):
        dx, dz = self.body.x - from_x, self.body.z - from_z
        n = math.hypot(dx, dz) or 1.0
        power = 0.5 if self.boss else 1.0
        v = C.KNOCKBACK_DISTANCE * power / C.KNOCKBACK_TIME
        self.knock_vx, self.knock_vz, self.knock_t = dx / n * v, dz / n * v, C.KNOCKBACK_TIME
        self.attack_timer = max(self.attack_timer, 0.4)         # a short stagger before it bites again
        self.flash = C.ENEMY_FLASH_TIME

    # ---- one frame ----------------------------------------------------
    def update(self, dt, player, safe, player_spd):
        """player: a game.physics.Body. safe: the player stands on Wood (slimes do not bite).
        Returns True when this frame is a bite (the caller works out the damage with combat.bite_damage)."""
        b = self.body
        self.flash = max(0.0, self.flash - dt)
        dx, dz = player.x - b.x, player.z - b.z
        dist = math.hypot(dx, dz)
        gap = dist - self.body.hw - player.hw
        self.chasing = dist <= C.ENEMY_CHASE_DISTANCE and abs(player.y - b.y) <= C.ENEMY_CHASE_DISTANCE
        if dist > 1e-6:
            self.facing = math.degrees(math.atan2(dx, dz))

        mx = mz = 0.0
        jump = False
        if self.knock_t > 0.0:
            self.knock_t -= dt
            mx, mz = self.knock_vx, self.knock_vz
        elif self.chasing and gap > 0.12:
            ux, uz = dx / dist, dz / dist
            ahead = b.hw + 0.3
            step = self.step_to(b.x + ux * ahead, b.z + uz * ahead)
            if step is not None:
                v = self.speed(player_spd)
                mx, mz = ux * v, uz * v
                jump = step > 0
        if mx or mz or jump or not self._settled():
            b.update(dt, mx, mz, jump)

        bite = False
        reach_y = player.y < b.y + self.size and player.y + player.h > b.y
        if self.chasing and gap <= C.ENEMY_REACH and reach_y:
            self.attack_timer -= dt
            if self.attack_timer <= 0.0 and not safe:
                bite = True
                self.attack_timer = C.ENEMY_ATTACK_INTERVAL
        else:
            self.attack_timer = max(self.attack_timer, C.ENEMY_FIRST_ATTACK_DELAY) if not self.chasing else self.attack_timer
        return bite

    def _settled(self):
        """Standing still on solid ground: no need to run the physics."""
        b = self.body
        return b.on_ground and self.world.is_blocking(math.floor(b.x), math.floor(b.y - 0.05), math.floor(b.z))


class EnemyManager:
    spawning = True                               # False: no ordinary slimes appear (tests); the Slime King still does

    def __init__(self, world, rng, mod_slimes=(), origin=(0.0, 0.0), extended=False):
        self.world = world
        self.rng = rng
        self.mod_slimes = mod_slimes
        self.origin = origin                      # where the game started (no slimes right there; distance for levels)
        self.extended = extended                  # the boss has fallen: wider colours, no level cap
        self.enemies = []
        self._chunks = {}                         # (cx, cz) -> [ActionEnemy] spawned for it
        self._night_done = set()                  # chunks that already got this night's extra slimes
        self._day = -1
        self.boss_defeated = False
        self.on_remove = None                     # callback(enemy): the drawing is destroyed by main.py

    # ---- creation -----------------------------------------------------
    def _level_at(self, spot, rng):
        top = max(int(surface_heights(self.world.seed, spot.x, spot.z)), C.SEA_LEVEL)
        depth = top - spot.y
        distance = math.hypot(spot.x + 0.5 - self.origin[0], spot.z + 0.5 - self.origin[1])
        return progression.enemy_level(depth, distance, rng, boss_defeated=self.boss_defeated)

    def _make(self, spot, chunk):
        rng = enemy_spawn.chunk_rng(self.world.seed, chunk[0], chunk[1], salt=977 + spot.x * 31 + spot.z * 17 + spot.y)
        stats = make_enemy(self._level_at(spot, rng), rng, extended=self.extended, mod_slimes=self.mod_slimes)
        return self.add(ActionEnemy(self.world, stats, spot.x + 0.5, spot.y, spot.z + 0.5, night_only=spot.night_only, chunk=chunk))

    def add(self, e):
        """Register a slime made by hand (tests, scripted fights). Its `chunk` decides when it goes away."""
        if e.chunk is None:
            e.chunk = (math.floor(e.x) >> 4, math.floor(e.z) >> 4)
        self.enemies.append(e)
        self._chunks.setdefault(e.chunk, []).append(e)
        return e

    def spawn_boss(self):
        """The Slime King on his Wood tile (only one at a time, never after he has fallen)."""
        if self.boss_defeated or any(e.boss and e.alive for e in self.enemies):
            return None
        x, y, z = boss_arena.boss_start(self.world.seed)
        chunk = (math.floor(x) >> 4, math.floor(z) >> 4)
        return self.add(ActionEnemy(self.world, make_boss(self.rng, extended=self.extended), x, y, z, boss=True, chunk=chunk))

    def boss(self):
        return next((e for e in self.enemies if e.boss and e.alive), None)

    # ---- chunks, night ------------------------------------------------
    def sync(self, loaded, world_time, player_xz, budget=1):
        """Call every frame with the set of loaded chunk keys. Spawns the slimes of up to `budget` newly loaded chunks, drops
        those of chunks that went away, and handles the night extras. Returns the enemies that were added or removed."""
        added, removed = [], []
        for key in [k for k in self._chunks if k not in loaded]:
            for e in self._chunks.pop(key):
                if e in self.enemies:
                    self._remove(e)
                    removed.append(e)
            self._night_done.discard(key)
        night = daytime.daylight(world_time) < 0.5
        day = int(world_time // C.DAY_LENGTH)
        if day != self._day:
            self._day = day
            self._night_done.clear()
        todo = 0
        for key in sorted(loaded, key=lambda k: (k[0] * 16 + 8 - player_xz[0]) ** 2 + (k[1] * 16 + 8 - player_xz[1]) ** 2):
            if todo >= budget or not self.spawning:
                break
            if key not in self._chunks:
                todo += 1
                self._chunks[key] = []
                for spot in enemy_spawn.base_spots(self.world, key[0], key[1], avoid=self.origin):
                    added.append(self._make(spot, key))
            elif night and key not in self._night_done:
                todo += 1
                self._night_done.add(key)
                for spot in enemy_spawn.night_spots(self.world, key[0], key[1], day, avoid=self.origin):
                    added.append(self._make(spot, key))
        if not night:                                            # dawn: night-only slimes that are not close to you fade away
            for e in [e for e in self.enemies if e.night_only and e.alive and
                      math.hypot(e.x - player_xz[0], e.z - player_xz[1]) > C.ENEMY_NIGHT_DESPAWN_DISTANCE]:
                self._remove(e)
                removed.append(e)
        boss_key = (math.floor(boss_arena.boss_start(self.world.seed)[0]) >> 4, math.floor(boss_arena.boss_start(self.world.seed)[2]) >> 4)
        if not self.boss_defeated and boss_key in loaded and self.boss() is None:
            b = self.spawn_boss()
            if b is not None:
                added.append(b)
        return added, removed

    def _remove(self, e):
        e.alive = False
        if e in self.enemies:
            self.enemies.remove(e)
        lst = self._chunks.get(e.chunk)
        if lst is not None and e in lst:
            lst.remove(e)
        if self.on_remove is not None:
            self.on_remove(e)

    def kill(self, e):
        self._remove(e)

    # ---- per frame ----------------------------------------------------
    def near(self, x, z, distance):
        d2 = distance * distance
        return [e for e in self.enemies if (e.x - x) ** 2 + (e.z - z) ** 2 <= d2]

    def update(self, dt, player, stats, rng):
        """Run the slimes near the player. Returns a list of (enemy, damage, multiplier) for the bites that landed this frame;
        the caller applies them (HP, flash, sound, death)."""
        safe = self.world.get_block(math.floor(player.x), math.floor(player.y - 0.05), math.floor(player.z)) == WOOD
        bites = []
        for e in self.near(player.x, player.z, C.ENEMY_ACTIVE_DISTANCE):
            if e.update(dt, player, safe, stats.spd):
                n, m = combat.bite_damage(stats, e.stats, rng)
                bites.append((e, n, m))
        return bites

    def any_chasing(self):
        return any(e.chasing for e in self.enemies)
